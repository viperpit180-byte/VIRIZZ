import type { RewriteStyle, StarterTopic, Tone } from '@/types';

export const colors = {
  bg: '#170B2E',
  bgDeep: '#0E0620',
  purple: '#6D28D9',
  fuchsia: '#D946EF',
  pink: '#FF4FA3',
  navy: '#172554',
  blue: '#2563EB',
  text: '#F8F7FF',
  textDim: 'rgba(248,247,255,0.68)',
  textFaint: 'rgba(248,247,255,0.42)',
  glass: 'rgba(255,255,255,0.07)',
  glassStrong: 'rgba(255,255,255,0.12)',
  border: 'rgba(255,255,255,0.14)',
  danger: '#FF6B8B',
  warn: '#FBBF24',
  ok: '#4ADE80',
} as const;

export const gradients = {
  background: ['#170B2E', '#1B1040', '#172554'],
  brand: ['#6D28D9', '#D946EF', '#FF4FA3'],
  cool: ['#172554', '#2563EB'],
  warm: ['#D946EF', '#FF4FA3'],
} as const;

export const radius = { sm: 10, md: 16, lg: 24, pill: 999 } as const;
export const space = { xs: 4, sm: 8, md: 16, lg: 24, xl: 32 } as const;

export const TONES: readonly Tone[] = ['Friendly', 'Funny', 'Confident', 'Casual', 'Professional', 'Short'];
export const ONBOARDING_TONES: readonly Tone[] = ['Friendly', 'Funny', 'Confident', 'Professional', 'Casual'];
export const REWRITE_STYLES: readonly RewriteStyle[] = ['Shorter', 'Clearer', 'Friendlier', 'More confident', 'Professional'];
export const TOPICS: readonly StarterTopic[] = ['Dating', 'Friends', 'School', 'Work', 'General'];

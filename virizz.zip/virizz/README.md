# Virizz

Virizz is an AI-powered messaging assistant: write replies, rewrite messages, change tone, and start conversations.
**This is Phase 1: a stable, polished app foundation. No real AI, accounts, or database are connected yet.**

## Tech stack
- Expo SDK 57 (React Native 0.86, React 19.2), TypeScript (strict), Expo Router, npm
- `expo-linear-gradient`, `expo-splash-screen`, `expo-status-bar`, `expo-constants`, `expo-linking`
- `react-native-safe-area-context`, `react-native-screens` (Expo Router peers)
- No state library: React state + Context + custom hooks. All of it runs in **Expo Go** (no native code).

## Installation
```bash
npm install
npx expo-doctor
npm run typecheck      # tsc --noEmit
```
If `expo-doctor` or `npm install` reports a version mismatch (package versions move within an SDK), run `npx expo install --fix` once, then commit the lockfile.

## Expo Go testing (Android)
1. Install **Expo Go** from Google Play (it must support SDK 57; otherwise get a matching build from https://expo.dev/go).
2. Run `npx expo start --tunnel` (works in GitHub Codespaces).
3. Scan the QR code with Expo Go.

Expo Go does not reproduce the standalone splash screen or the adaptive icon exactly; check those in a later standalone build.

## Project structure
```
app/            Expo Router screens (onboarding, auth/, (tabs)/, tools/, item/[id])
components/     Shared UI (Screen, GlassCard, GradientButton, AssistantForm, ...)
constants/      Theme colors and option lists
hooks/          useSession, useLibrary, useAssist
lib/            config, validation, navigation helpers, formatting
services/       ai.ts, auth.ts, starters.ts, library.ts  (the swap-in points for Phase 2)
types/          Shared TypeScript types
assets/images/  icon.png, adaptive-icon*.png, splash-icon.png, favicon.png
```

## Environment variables (public only)
Copy `.env.example` to `.env`. All are optional; the app runs with none set.
- `EXPO_PUBLIC_API_URL` – your future secure AI backend
- `EXPO_PUBLIC_SUPABASE_URL`, `EXPO_PUBLIC_SUPABASE_ANON_KEY` – public Supabase values only

Never put AI keys, service-role keys, or passwords in this app.

## Phase 1 status
| Feature | Status |
|---|---|
| Onboarding, navigation, tabs, all screens, input validation, loading/error/empty states | Implemented |
| Splash + icon configuration | Implemented (verify in a standalone build) |
| AI Reply / Rewrite / Change Tone | UI implemented; **Requires backend configuration** (`services/ai.ts` returns "AI service not connected yet") |
| Conversation Starter | Local fixed list, **not AI** (Prepared for Phase 2) |
| History / Saved | In-memory **sample data**; resets on restart (Prepared for Phase 2) |
| Sign in / Sign up / Reset password | UI + validation only; **Requires backend configuration** (Supabase). Use "Continue as guest" |
| Onboarding/guest state persistence | Not persisted; resets on restart |

## Planned Phase 2
Secure AI backend, Supabase auth and storage (history, saved), persisted settings, standalone EAS builds, then later: subscriptions and a custom keyboard (needs native code and a development build).

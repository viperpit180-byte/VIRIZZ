import { StyleSheet, Text, TextInput, View, type TextInputProps } from 'react-native';
import { colors, radius } from '@/constants/theme';

interface Props extends TextInputProps {
  label: string;
  error?: string | null;
  multilineHeight?: number;
}

export function TextField({ label, error, multilineHeight, style, ...rest }: Props) {
  return (
    <View style={styles.wrap}>
      <Text style={styles.label}>{label}</Text>
      <TextInput
        placeholderTextColor={colors.textFaint}
        selectionColor={colors.pink}
        accessibilityLabel={label}
        textAlignVertical={rest.multiline ? 'top' : 'center'}
        style={[styles.input, rest.multiline && { minHeight: multilineHeight ?? 140 }, error ? styles.errorBorder : null, style]}
        {...rest}
      />
      {error ? <Text style={styles.error}>{error}</Text> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { gap: 8 },
  label: { color: colors.textDim, fontSize: 13, fontWeight: '600', letterSpacing: 0.3 },
  input: {
    backgroundColor: colors.glass,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    color: colors.text,
    fontSize: 16,
    paddingHorizontal: 16,
    paddingVertical: 14,
  },
  errorBorder: { borderColor: colors.danger },
  error: { color: colors.danger, fontSize: 13 },
});

import { useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { BackHeader } from '@/components/BackHeader';
import { GlassCard } from '@/components/GlassCard';
import { GradientButton } from '@/components/GradientButton';
import { Notice } from '@/components/Notice';
import { OptionChips } from '@/components/OptionChips';
import { Screen } from '@/components/Screen';
import { TextField } from '@/components/TextField';
import { colors } from '@/constants/theme';
import { useAssist } from '@/hooks/useAssist';
import { validateMessage } from '@/lib/validation';
import type { ServiceResult } from '@/types';

interface Props<T extends string> {
  title: string;
  subtitle: string;
  inputLabel: string;
  placeholder: string;
  optionLabel: string;
  options: readonly T[];
  initialOption: T;
  actionLabel: string;
  showBack?: boolean;
  /** Must go through services/ai.ts. */
  action: (message: string, option: T) => Promise<ServiceResult<{ text: string }>>;
}

/** Shared screen for Reply / Rewrite / Change Tone: input + options + result. */
export function AssistantForm<T extends string>(props: Props<T>) {
  const { title, subtitle, inputLabel, placeholder, optionLabel, options, initialOption, actionLabel, showBack = false, action } = props;
  const [message, setMessage] = useState('');
  const [option, setOption] = useState<T>(initialOption);
  const [inputError, setInputError] = useState<string | null>(null);
  const { state, run, reset } = useAssist();

  const submit = () => {
    const invalid = validateMessage(message);
    setInputError(invalid);
    if (invalid) return;
    void run(() => action(message, option));
  };

  return (
    <Screen>
      <BackHeader title={title} subtitle={subtitle} showBack={showBack} />
      <TextField
        label={inputLabel}
        placeholder={placeholder}
        value={message}
        multiline
        maxLength={2000}
        onChangeText={(t) => {
          setMessage(t);
          if (inputError) setInputError(null);
          if (state.status !== 'idle' && state.status !== 'loading') reset();
        }}
        error={inputError}
      />
      <View style={styles.group}>
        <Text style={styles.groupLabel}>{optionLabel}</Text>
        <OptionChips options={options} value={option} onChange={setOption} />
      </View>
      <GradientButton label={actionLabel} onPress={submit} loading={state.status === 'loading'} />

      {state.status === 'unavailable' ? <Notice status="Requires backend configuration" message={state.message} /> : null}
      {state.status === 'error' ? <Text style={styles.error}>{state.message}</Text> : null}
      {state.status === 'success' ? (
        <GlassCard>
          <Text style={styles.result}>{state.text}</Text>
        </GlassCard>
      ) : null}
    </Screen>
  );
}

const styles = StyleSheet.create({
  group: { gap: 10 },
  groupLabel: { color: colors.textDim, fontSize: 13, fontWeight: '600', letterSpacing: 0.3 },
  error: { color: colors.danger, fontSize: 14 },
  result: { color: colors.text, fontSize: 16, lineHeight: 24 },
});

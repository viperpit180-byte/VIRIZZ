import { Image, StyleSheet, Text, View } from 'react-native';
import { colors, radius } from '@/constants/theme';

export function AiBadge() {
  return (
    <View style={styles.badge}>
      <Image source={require('../assets/images/icon.png')} style={styles.logo} accessibilityIgnoresInvertColors />
      <Text style={styles.text}>Virizz AI</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  badge: { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: colors.glassStrong, borderRadius: radius.pill, paddingVertical: 4, paddingLeft: 4, paddingRight: 12, alignSelf: 'flex-start' },
  logo: { width: 22, height: 22, borderRadius: 7 },
  text: { color: colors.text, fontSize: 12, fontWeight: '700' },
});

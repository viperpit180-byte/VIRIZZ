import type { ReactNode } from 'react';
import { KeyboardAvoidingView, Platform, ScrollView, StyleSheet, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeAreaView, type Edge } from 'react-native-safe-area-context';
import { gradients, space } from '@/constants/theme';

interface Props {
  children: ReactNode;
  scroll?: boolean;
  edges?: readonly Edge[];
}

/** Gradient background + safe area + keyboard-safe scrolling. */
export function Screen({ children, scroll = true, edges = ['top'] }: Props) {
  return (
    <LinearGradient colors={gradients.background} style={styles.fill}>
      <SafeAreaView style={styles.fill} edges={edges}>
        <KeyboardAvoidingView style={styles.fill} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
          {scroll ? (
            <ScrollView
              style={styles.fill}
              contentContainerStyle={styles.content}
              keyboardShouldPersistTaps="handled"
              keyboardDismissMode="on-drag"
              showsVerticalScrollIndicator={false}
            >
              {children}
            </ScrollView>
          ) : (
            <View style={[styles.fill, styles.content]}>{children}</View>
          )}
        </KeyboardAvoidingView>
      </SafeAreaView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  fill: { flex: 1 },
  content: { padding: space.md, paddingBottom: space.xl * 2, gap: space.md, flexGrow: 1 },
});

import { StyleSheet, Text, View } from 'react-native';
import { colors, radius } from '@/constants/theme';
import type { FeatureStatus } from '@/types';

const STATUS_COLOR: Record<FeatureStatus, string> = {
  Implemented: colors.ok,
  'Prepared for Phase 2': colors.warn,
  'Requires backend configuration': colors.pink,
};

export function StatusBadge({ status }: { status: FeatureStatus }) {
  const color = STATUS_COLOR[status];
  return (
    <View style={[styles.badge, { borderColor: color }]}>
      <Text style={[styles.badgeText, { color }]}>{status}</Text>
    </View>
  );
}

interface NoticeProps {
  status: FeatureStatus;
  message: string;
}

/** Honest banner explaining what is and is not functional. */
export function Notice({ status, message }: NoticeProps) {
  return (
    <View style={styles.box}>
      <StatusBadge status={status} />
      <Text style={styles.message}>{message}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  box: { backgroundColor: colors.glass, borderRadius: radius.md, padding: 12, gap: 8, borderWidth: 1, borderColor: colors.border },
  badge: { alignSelf: 'flex-start', borderWidth: 1, borderRadius: radius.pill, paddingHorizontal: 10, paddingVertical: 3 },
  badgeText: { fontSize: 11, fontWeight: '700', letterSpacing: 0.4 },
  message: { color: colors.textDim, fontSize: 13, lineHeight: 19 },
});

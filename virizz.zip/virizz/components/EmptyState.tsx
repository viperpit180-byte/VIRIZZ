import { StyleSheet, Text, View } from 'react-native';
import { colors } from '@/constants/theme';

export function EmptyState({ emoji, title, message }: { emoji: string; title: string; message: string }) {
  return (
    <View style={styles.box}>
      <Text style={styles.emoji}>{emoji}</Text>
      <Text style={styles.title}>{title}</Text>
      <Text style={styles.message}>{message}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  box: { alignItems: 'center', padding: 32, gap: 8 },
  emoji: { fontSize: 40 },
  title: { color: colors.text, fontSize: 18, fontWeight: '700' },
  message: { color: colors.textDim, fontSize: 14, textAlign: 'center', lineHeight: 20 },
});

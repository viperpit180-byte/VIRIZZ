import { ActivityIndicator, Pressable, StyleSheet, Text, type StyleProp, type ViewStyle } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { colors, gradients, radius } from '@/constants/theme';

interface Props {
  label: string;
  onPress: () => void;
  loading?: boolean;
  disabled?: boolean;
  variant?: 'primary' | 'ghost';
  style?: StyleProp<ViewStyle>;
}

export function GradientButton({ label, onPress, loading = false, disabled = false, variant = 'primary', style }: Props) {
  const inactive = disabled || loading;
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={label}
      accessibilityState={{ disabled: inactive, busy: loading }}
      disabled={inactive}
      onPress={onPress}
      style={({ pressed }) => [styles.wrap, inactive && styles.inactive, pressed && styles.pressed, style]}
    >
      {variant === 'primary' ? (
        <LinearGradient colors={gradients.brand} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={styles.inner}>
          {loading ? <ActivityIndicator color={colors.text} /> : <Text style={styles.label}>{label}</Text>}
        </LinearGradient>
      ) : (
        <>
          {loading ? <ActivityIndicator color={colors.text} style={styles.inner} /> : <Text style={[styles.label, styles.ghostLabel]}>{label}</Text>}
        </>
      )}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  wrap: { borderRadius: radius.pill, overflow: 'hidden', minHeight: 52, justifyContent: 'center' },
  inner: { minHeight: 52, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 24 },
  label: { color: colors.text, fontSize: 16, fontWeight: '700', textAlign: 'center' },
  ghostLabel: { color: colors.textDim, paddingVertical: 14 },
  inactive: { opacity: 0.55 },
  pressed: { opacity: 0.85 },
});

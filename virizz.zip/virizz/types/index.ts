export type Tone =
  | 'Friendly'
  | 'Funny'
  | 'Confident'
  | 'Casual'
  | 'Professional'
  | 'Short';

export type RewriteStyle =
  | 'Shorter'
  | 'Clearer'
  | 'Friendlier'
  | 'More confident'
  | 'Professional';

export type StarterTopic = 'Dating' | 'Friends' | 'School' | 'Work' | 'General';

export type ItemKind = 'Reply' | 'Rewrite' | 'Starter' | 'Tone';

/** Honest status labels used across the UI. */
export type FeatureStatus =
  | 'Implemented'
  | 'Prepared for Phase 2'
  | 'Requires backend configuration';

export type ServiceResult<T> =
  | { ok: true; data: T }
  | { ok: false; reason: 'invalid_input' | 'not_configured' | 'not_implemented' | 'network' | 'unknown'; message: string };

export interface LibraryItem {
  id: string;
  kind: ItemKind;
  createdAt: string; // ISO date
  input: string;
  output: string;
  /** true = hard-coded development sample, NOT produced by AI and NOT from a database */
  sample: boolean;
}

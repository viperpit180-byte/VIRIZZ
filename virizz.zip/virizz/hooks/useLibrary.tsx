import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from 'react';
import { SAMPLE_HISTORY, SAMPLE_SAVED } from '@/services/library';
import type { LibraryItem } from '@/types';

interface LibraryValue {
  history: readonly LibraryItem[];
  saved: readonly LibraryItem[];
  isSaved: (id: string) => boolean;
  toggleSaved: (item: LibraryItem) => void;
  findItem: (id: string) => LibraryItem | undefined;
}

const LibraryContext = createContext<LibraryValue | null>(null);

export function LibraryProvider({ children }: { children: ReactNode }) {
  const [saved, setSaved] = useState<readonly LibraryItem[]>(SAMPLE_SAVED);
  const history = SAMPLE_HISTORY;

  const isSaved = useCallback((id: string) => saved.some((s) => s.id === id), [saved]);
  const toggleSaved = useCallback((item: LibraryItem) => {
    setSaved((prev) => (prev.some((s) => s.id === item.id) ? prev.filter((s) => s.id !== item.id) : [item, ...prev]));
  }, []);
  const findItem = useCallback(
    (id: string) => history.find((h) => h.id === id) ?? saved.find((s) => s.id === id),
    [history, saved],
  );

  const value = useMemo(() => ({ history, saved, isSaved, toggleSaved, findItem }), [history, saved, isSaved, toggleSaved, findItem]);
  return <LibraryContext.Provider value={value}>{children}</LibraryContext.Provider>;
}

export function useLibrary(): LibraryValue {
  const ctx = useContext(LibraryContext);
  if (!ctx) throw new Error('useLibrary must be used inside <LibraryProvider>');
  return ctx;
}

import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from 'react';

/**
 * Phase 1 session state (memory only, resets when the app restarts).
 * No real account exists; "guest" simply means "preview mode".
 */
interface SessionValue {
  onboarded: boolean;
  guest: boolean;
  completeOnboarding: () => void;
  continueAsGuest: () => void;
  signOut: () => void;
}

const SessionContext = createContext<SessionValue | null>(null);

export function SessionProvider({ children }: { children: ReactNode }) {
  const [onboarded, setOnboarded] = useState(false);
  const [guest, setGuest] = useState(false);

  const completeOnboarding = useCallback(() => setOnboarded(true), []);
  const continueAsGuest = useCallback(() => {
    setOnboarded(true);
    setGuest(true);
  }, []);
  const signOut = useCallback(() => setGuest(false), []);

  const value = useMemo(() => ({ onboarded, guest, completeOnboarding, continueAsGuest, signOut }), [onboarded, guest, completeOnboarding, continueAsGuest, signOut]);
  return <SessionContext.Provider value={value}>{children}</SessionContext.Provider>;
}

export function useSession(): SessionValue {
  const ctx = useContext(SessionContext);
  if (!ctx) throw new Error('useSession must be used inside <SessionProvider>');
  return ctx;
}

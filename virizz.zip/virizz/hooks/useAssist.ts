import { useCallback, useRef, useState } from 'react';
import type { ServiceResult } from '@/types';

export type AssistState =
  | { status: 'idle' }
  | { status: 'loading' }
  | { status: 'success'; text: string }
  | { status: 'unavailable'; message: string }
  | { status: 'error'; message: string };

/** Runs an async service call and maps it to a UI state. Never throws. */
export function useAssist() {
  const [state, setState] = useState<AssistState>({ status: 'idle' });
  const runId = useRef(0);

  const run = useCallback(async (call: () => Promise<ServiceResult<{ text: string }>>) => {
    const id = ++runId.current;
    setState({ status: 'loading' });
    try {
      const result = await call();
      if (id !== runId.current) return;
      if (result.ok) setState({ status: 'success', text: result.data.text });
      else if (result.reason === 'invalid_input') setState({ status: 'error', message: result.message });
      else setState({ status: 'unavailable', message: result.message });
    } catch {
      if (id === runId.current) setState({ status: 'error', message: 'Unexpected error. Please try again.' });
    }
  }, []);

  const reset = useCallback(() => {
    runId.current += 1;
    setState({ status: 'idle' });
  }, []);

  return { state, run, reset };
}

import type { Router } from 'expo-router';

/** Navigation helpers that never throw. */
export function safePush(router: Router, href: string): void {
  try {
    router.push(href as never);
  } catch {
    try {
      router.replace('/(tabs)/home' as never);
    } catch {
      /* nothing else we can do; stay on the current screen */
    }
  }
}

export function safeReplace(router: Router, href: string): void {
  try {
    router.replace(href as never);
  } catch {
    /* stay on the current screen */
  }
}

export function safeBack(router: Router, fallback = '/(tabs)/home'): void {
  try {
    if (router.canGoBack()) router.back();
    else router.replace(fallback as never);
  } catch {
    /* stay on the current screen */
  }
}

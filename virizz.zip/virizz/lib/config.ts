/**
 * Public, non-secret configuration. Values come from EXPO_PUBLIC_* variables.
 * Everything is optional: the app runs with none of them set.
 */
const read = (value: string | undefined): string => (value ?? '').trim();

export const config = {
  apiUrl: read(process.env.EXPO_PUBLIC_API_URL),
  supabaseUrl: read(process.env.EXPO_PUBLIC_SUPABASE_URL),
  supabaseAnonKey: read(process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY),
} as const;

export const isBackendConfigured = config.apiUrl.length > 0;
export const isAuthConfigured = config.supabaseUrl.length > 0 && config.supabaseAnonKey.length > 0;

export const MAX_INPUT_LENGTH = 2000;

/** Returns an error message, or null when the text is acceptable. */
export function validateMessage(text: string, label = 'message'): string | null {
  const trimmed = text.trim();
  if (trimmed.length === 0) return `Please enter a ${label} first.`;
  if (trimmed.length < 2) return `That ${label} is too short.`;
  if (trimmed.length > MAX_INPUT_LENGTH) return `That ${label} is too long (max ${MAX_INPUT_LENGTH} characters).`;
  return null;
}

export function validateEmail(email: string): string | null {
  const value = email.trim();
  if (!value) return 'Please enter your email.';
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) return 'Please enter a valid email address.';
  return null;
}

export function validatePassword(password: string): string | null {
  if (!password) return 'Please enter a password.';
  if (password.length < 8) return 'Password must be at least 8 characters.';
  return null;
}

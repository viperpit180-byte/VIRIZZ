import { useState } from 'react';
import { View } from 'react-native';
import { BackHeader } from '@/components/BackHeader';
import { GradientButton } from '@/components/GradientButton';
import { Notice } from '@/components/Notice';
import { Screen } from '@/components/Screen';
import { TextField } from '@/components/TextField';
import { authService } from '@/services/auth';

export default function ForgotPassword() {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [unavailable, setUnavailable] = useState<string | null>(null);

  const submit = async () => {
    setError(null);
    setUnavailable(null);
    setLoading(true);
    try {
      const result = await authService.sendPasswordReset(email);
      if (result.ok) return;
      if (result.reason === 'invalid_input') setError(result.message);
      else setUnavailable(result.message);
    } catch {
      setError('Unexpected error. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Screen edges={['top', 'bottom']}>
      <BackHeader title="Reset password" subtitle="We will email you a reset link once accounts are connected." />
      <View style={{ height: 8 }} />
      <TextField label="Email" value={email} onChangeText={setEmail} autoCapitalize="none" autoCorrect={false} keyboardType="email-address" placeholder="you@example.com" error={error} />
      {unavailable ? <Notice status="Requires backend configuration" message={unavailable} /> : null}
      <GradientButton label="Send Reset Link" onPress={() => void submit()} loading={loading} />
    </Screen>
  );
}

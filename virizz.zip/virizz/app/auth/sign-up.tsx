import { useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { BackHeader } from '@/components/BackHeader';
import { GradientButton } from '@/components/GradientButton';
import { Notice } from '@/components/Notice';
import { Screen } from '@/components/Screen';
import { TextField } from '@/components/TextField';
import { colors } from '@/constants/theme';
import { safeBack } from '@/lib/navigation';
import { authService } from '@/services/auth';

export default function SignUp() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [unavailable, setUnavailable] = useState<string | null>(null);

  const submit = async () => {
    setError(null);
    setUnavailable(null);
    if (password !== confirm) {
      setError('Passwords do not match.');
      return;
    }
    setLoading(true);
    try {
      const result = await authService.signUp(email, password);
      if (result.ok) safeBack(router, '/auth/sign-in');
      else if (result.reason === 'invalid_input') setError(result.message);
      else setUnavailable(result.message);
    } catch {
      setError('Unexpected error. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Screen edges={['top', 'bottom']}>
      <BackHeader title="Create account" subtitle="Join Virizz" />
      <View style={styles.gap} />
      <TextField label="Email" value={email} onChangeText={setEmail} autoCapitalize="none" autoCorrect={false} keyboardType="email-address" placeholder="you@example.com" />
      <TextField label="Password" value={password} onChangeText={setPassword} secureTextEntry autoCapitalize="none" placeholder="At least 8 characters" />
      <TextField label="Confirm password" value={confirm} onChangeText={setConfirm} secureTextEntry autoCapitalize="none" error={error} />
      {unavailable ? <Notice status="Requires backend configuration" message={unavailable} /> : null}
      <GradientButton label="Sign Up" onPress={() => void submit()} loading={loading} />
      <Text style={styles.note}>Accounts are not available in Phase 1.</Text>
    </Screen>
  );
}

const styles = StyleSheet.create({
  gap: { height: 8 },
  note: { color: colors.textFaint, fontSize: 12, textAlign: 'center' },
});

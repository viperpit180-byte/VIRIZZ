import { useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { GradientButton } from '@/components/GradientButton';
import { Notice } from '@/components/Notice';
import { Screen } from '@/components/Screen';
import { TextField } from '@/components/TextField';
import { colors } from '@/constants/theme';
import { useSession } from '@/hooks/useSession';
import { safePush, safeReplace } from '@/lib/navigation';
import { authService } from '@/services/auth';

export default function SignIn() {
  const router = useRouter();
  const { continueAsGuest } = useSession();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [unavailable, setUnavailable] = useState<string | null>(null);

  const submit = async () => {
    setError(null);
    setUnavailable(null);
    setLoading(true);
    try {
      const result = await authService.signIn(email, password);
      if (result.ok) safeReplace(router, '/(tabs)/home');
      else if (result.reason === 'invalid_input') setError(result.message);
      else setUnavailable(result.message);
    } catch {
      setError('Unexpected error. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const guest = () => {
    continueAsGuest();
    safeReplace(router, '/(tabs)/home');
  };

  return (
    <Screen>
      <View style={styles.head}>
        <Text style={styles.title}>Welcome back</Text>
        <Text style={styles.subtitle}>Sign in to Virizz</Text>
      </View>
      <TextField label="Email" value={email} onChangeText={setEmail} autoCapitalize="none" autoCorrect={false} keyboardType="email-address" placeholder="you@example.com" />
      <TextField label="Password" value={password} onChangeText={setPassword} secureTextEntry autoCapitalize="none" placeholder="At least 8 characters" error={error} />
      {unavailable ? <Notice status="Requires backend configuration" message={unavailable} /> : null}
      <GradientButton label="Sign In" onPress={() => void submit()} loading={loading} />
      <GradientButton label="Continue as guest (Phase 1 preview)" variant="ghost" onPress={guest} />
      <View style={styles.links}>
        <Pressable onPress={() => safePush(router, '/auth/forgot-password')} hitSlop={8}>
          <Text style={styles.link}>Forgot password?</Text>
        </Pressable>
        <Pressable onPress={() => safePush(router, '/auth/sign-up')} hitSlop={8}>
          <Text style={styles.link}>Create account</Text>
        </Pressable>
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  head: { gap: 4, marginTop: 24, marginBottom: 8 },
  title: { color: colors.text, fontSize: 32, fontWeight: '800' },
  subtitle: { color: colors.textDim, fontSize: 16 },
  links: { flexDirection: 'row', justifyContent: 'space-between' },
  link: { color: colors.pink, fontWeight: '600', fontSize: 14 },
});

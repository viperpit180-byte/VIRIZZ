import { Redirect } from 'expo-router';
import { useSession } from '@/hooks/useSession';

export default function Index() {
  const { onboarded, guest } = useSession();
  if (!onboarded) return <Redirect href="/onboarding" />;
  if (!guest) return <Redirect href="/auth/sign-in" />;
  return <Redirect href="/(tabs)/home" />;
}

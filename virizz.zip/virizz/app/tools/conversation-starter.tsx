import { useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { BackHeader } from '@/components/BackHeader';
import { GlassCard } from '@/components/GlassCard';
import { GradientButton } from '@/components/GradientButton';
import { Notice } from '@/components/Notice';
import { OptionChips } from '@/components/OptionChips';
import { Screen } from '@/components/Screen';
import { colors, TOPICS } from '@/constants/theme';
import { createLocalStarter } from '@/services/starters';
import type { StarterTopic } from '@/types';

export default function ConversationStarter() {
  const [topic, setTopic] = useState<StarterTopic>('General');
  const [starter, setStarter] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const create = () => {
    setError(null);
    try {
      const result = createLocalStarter(topic);
      if (result.ok) setStarter(result.data.text);
      else {
        setStarter(null);
        setError(result.message);
      }
    } catch {
      setStarter(null);
      setError('Could not create a starter. Please try again.');
    }
  };

  return (
    <Screen edges={['top', 'bottom']}>
      <BackHeader title="Conversation Starter" subtitle="Pick a topic to break the ice." />
      <View style={styles.group}>
        <Text style={styles.label}>Topic</Text>
        <OptionChips options={TOPICS} value={topic} onChange={(t) => { setTopic(t); setStarter(null); }} />
      </View>
      <GradientButton label="Create Starter" onPress={create} />
      {error ? <Text style={styles.error}>{error}</Text> : null}
      {starter ? (
        <>
          <GlassCard>
            <Text style={styles.result}>{starter}</Text>
          </GlassCard>
          <Notice status="Prepared for Phase 2" message="Local development starter from a fixed list. It is not AI-generated. Real AI starters arrive with the Phase 2 backend." />
        </>
      ) : null}
    </Screen>
  );
}

const styles = StyleSheet.create({
  group: { gap: 10, marginTop: 8 },
  label: { color: colors.textDim, fontSize: 13, fontWeight: '600' },
  error: { color: colors.danger, fontSize: 14 },
  result: { color: colors.text, fontSize: 17, lineHeight: 26 },
});

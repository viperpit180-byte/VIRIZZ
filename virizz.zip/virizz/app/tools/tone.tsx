import { AssistantForm } from '@/components/AssistantForm';
import { TONES } from '@/constants/theme';
import { aiService } from '@/services/ai';

export default function ToneScreen() {
  return (
    <AssistantForm
      title="Change Tone"
      subtitle="Keep your meaning, change how it sounds."
      inputLabel="Your message"
      placeholder="Type or paste your message…"
      optionLabel="New tone"
      options={TONES}
      initialOption="Friendly"
      actionLabel="Change Tone"
      showBack
      action={(message, tone) => aiService.changeTone(message, tone)}
    />
  );
}

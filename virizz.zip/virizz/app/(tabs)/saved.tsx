import { Pressable, StyleSheet, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { EmptyState } from '@/components/EmptyState';
import { GlassCard } from '@/components/GlassCard';
import { Notice } from '@/components/Notice';
import { Screen } from '@/components/Screen';
import { colors } from '@/constants/theme';
import { useLibrary } from '@/hooks/useLibrary';
import { formatDate, preview } from '@/lib/format';
import { safePush } from '@/lib/navigation';

export default function Saved() {
  const router = useRouter();
  const { saved, toggleSaved } = useLibrary();
  return (
    <Screen>
      <Text style={styles.title}>Saved</Text>
      <Notice status="Prepared for Phase 2" message="Saved items live in local app memory and reset when the app restarts. Supabase sync is planned." />
      {saved.length === 0 ? (
        <EmptyState emoji="💜" title="Nothing saved" message="Open an item from History and tap Save to keep it here." />
      ) : (
        saved.map((item) => (
          <GlassCard key={item.id} onPress={() => safePush(router, `/item/${item.id}`)}>
            <View style={styles.row}>
              <Text style={styles.kind}>{item.kind} · {formatDate(item.createdAt)}</Text>
              <Pressable accessibilityRole="button" accessibilityLabel="Unsave" onPress={() => toggleSaved(item)} hitSlop={10}>
                <Text style={styles.unsave}>Unsave</Text>
              </Pressable>
            </View>
            <Text style={styles.preview}>{preview(item.output)}</Text>
          </GlassCard>
        ))
      )}
    </Screen>
  );
}

const styles = StyleSheet.create({
  title: { color: colors.text, fontSize: 30, fontWeight: '800', marginTop: 8 },
  row: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6 },
  kind: { color: colors.pink, fontWeight: '700', fontSize: 12 },
  unsave: { color: colors.danger, fontWeight: '700', fontSize: 12 },
  preview: { color: colors.textDim, fontSize: 14, lineHeight: 20 },
});

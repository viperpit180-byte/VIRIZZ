import { Text } from 'react-native';
import { Redirect, Tabs } from 'expo-router';
import { colors } from '@/constants/theme';
import { useSession } from '@/hooks/useSession';

const icon = (glyph: string) =>
  function TabIcon({ color }: { color: string }) {
    return <Text style={{ color, fontSize: 18 }}>{glyph}</Text>;
  };

export default function TabsLayout() {
  const { onboarded, guest } = useSession();
  if (!onboarded) return <Redirect href="/onboarding" />;
  if (!guest) return <Redirect href="/auth/sign-in" />;

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: colors.pink,
        tabBarInactiveTintColor: colors.textFaint,
        tabBarStyle: { backgroundColor: colors.bgDeep, borderTopColor: colors.border },
        tabBarLabelStyle: { fontSize: 10, fontWeight: '600' },
      }}
    >
      <Tabs.Screen name="home" options={{ title: 'Home', tabBarIcon: icon('⌂') }} />
      <Tabs.Screen name="reply" options={{ title: 'Reply', tabBarIcon: icon('✦') }} />
      <Tabs.Screen name="rewrite" options={{ title: 'Rewrite', tabBarIcon: icon('✎') }} />
      <Tabs.Screen name="history" options={{ title: 'History', tabBarIcon: icon('◷') }} />
      <Tabs.Screen name="saved" options={{ title: 'Saved', tabBarIcon: icon('♥') }} />
      <Tabs.Screen name="settings" options={{ title: 'Settings', tabBarIcon: icon('⚙') }} />
    </Tabs>
  );
}

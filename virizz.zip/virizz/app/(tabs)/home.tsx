import { StyleSheet, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { AiBadge } from '@/components/AiBadge';
import { EmptyState } from '@/components/EmptyState';
import { GlassCard } from '@/components/GlassCard';
import { Screen } from '@/components/Screen';
import { colors, radius } from '@/constants/theme';
import { useLibrary } from '@/hooks/useLibrary';
import { formatDate, preview } from '@/lib/format';
import { safePush } from '@/lib/navigation';

interface Action {
  title: string;
  hint: string;
  glyph: string;
  href: string;
  colors: readonly [string, string];
}

const ACTIONS: readonly Action[] = [
  { title: 'AI Reply', hint: 'Answer a message', glyph: '✦', href: '/(tabs)/reply', colors: ['#6D28D9', '#D946EF'] },
  { title: 'Rewrite', hint: 'Polish your wording', glyph: '✎', href: '/(tabs)/rewrite', colors: ['#D946EF', '#FF4FA3'] },
  { title: 'Conversation Starter', hint: 'Break the ice', glyph: '💬', href: '/tools/conversation-starter', colors: ['#172554', '#2563EB'] },
  { title: 'Change Tone', hint: 'Match the mood', glyph: '🎚', href: '/tools/tone', colors: ['#2563EB', '#6D28D9'] },
];

export default function Home() {
  const router = useRouter();
  const { history } = useLibrary();
  const recent = history.slice(0, 3);

  return (
    <Screen>
      <View style={styles.header}>
        <View style={styles.headerText}>
          <Text style={styles.hey}>Hey 👋</Text>
          <Text style={styles.sub}>Ready to write something?</Text>
        </View>
        <AiBadge />
      </View>

      <View style={styles.grid}>
        {ACTIONS.map((a) => (
          <GlassCard key={a.title} onPress={() => safePush(router, a.href)} style={styles.card} accessibilityLabel={a.title}>
            <LinearGradient colors={a.colors} style={styles.iconWrap}>
              <Text style={styles.glyph}>{a.glyph}</Text>
            </LinearGradient>
            <Text style={styles.cardTitle}>{a.title}</Text>
            <Text style={styles.cardHint}>{a.hint}</Text>
          </GlassCard>
        ))}
      </View>

      <Text style={styles.section}>Recent activity</Text>
      <Text style={styles.sample}>Sample development data. Nothing is stored yet.</Text>
      {recent.length === 0 ? (
        <EmptyState emoji="🫧" title="Nothing yet" message="Your generated messages will show up here." />
      ) : (
        recent.map((item) => (
          <GlassCard key={item.id} onPress={() => safePush(router, `/item/${item.id}`)}>
            <Text style={styles.kind}>{item.kind} · {formatDate(item.createdAt)}</Text>
            <Text style={styles.preview}>{preview(item.output)}</Text>
          </GlassCard>
        ))
      )}
    </Screen>
  );
}

const styles = StyleSheet.create({
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginTop: 8 },
  headerText: { flex: 1, paddingRight: 8 },
  hey: { color: colors.text, fontSize: 34, fontWeight: '800' },
  sub: { color: colors.textDim, fontSize: 17, marginTop: 4 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 },
  card: { width: '48%', flexGrow: 1, gap: 6 },
  iconWrap: { width: 46, height: 46, borderRadius: radius.md, alignItems: 'center', justifyContent: 'center', marginBottom: 6 },
  glyph: { fontSize: 22, color: colors.text },
  cardTitle: { color: colors.text, fontSize: 16, fontWeight: '700' },
  cardHint: { color: colors.textDim, fontSize: 13 },
  section: { color: colors.text, fontSize: 20, fontWeight: '700', marginTop: 8 },
  sample: { color: colors.textFaint, fontSize: 12, marginTop: -8 },
  kind: { color: colors.pink, fontSize: 12, fontWeight: '700', marginBottom: 6 },
  preview: { color: colors.textDim, fontSize: 14, lineHeight: 20 },
});

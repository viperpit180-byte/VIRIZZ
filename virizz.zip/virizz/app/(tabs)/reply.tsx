import { AssistantForm } from '@/components/AssistantForm';
import { TONES } from '@/constants/theme';
import { aiService } from '@/services/ai';

export default function ReplyScreen() {
  return (
    <AssistantForm
      title="AI Reply"
      subtitle="Paste a message and choose how you want to sound."
      inputLabel="Paste the message"
      placeholder="Paste the message you received…"
      optionLabel="Tone"
      options={TONES}
      initialOption="Friendly"
      actionLabel="Generate Reply"
      action={(message, tone) => aiService.generateReply(message, tone)}
    />
  );
}

import { StyleSheet, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import Constants from 'expo-constants';
import { GlassCard } from '@/components/GlassCard';
import { GradientButton } from '@/components/GradientButton';
import { StatusBadge } from '@/components/Notice';
import { Screen } from '@/components/Screen';
import { colors } from '@/constants/theme';
import { useSession } from '@/hooks/useSession';
import { isAuthConfigured, isBackendConfigured } from '@/lib/config';
import { safeReplace } from '@/lib/navigation';
import type { FeatureStatus } from '@/types';

function Row({ title, detail, status }: { title: string; detail: string; status?: FeatureStatus }) {
  return (
    <View style={styles.row}>
      <Text style={styles.rowTitle}>{title}</Text>
      <Text style={styles.rowDetail}>{detail}</Text>
      {status ? <StatusBadge status={status} /> : null}
    </View>
  );
}

export default function Settings() {
  const router = useRouter();
  const { signOut } = useSession();
  const version = Constants.expoConfig?.version ?? '0.1.0';

  const leave = () => {
    signOut();
    safeReplace(router, '/auth/sign-in');
  };

  return (
    <Screen>
      <Text style={styles.title}>Settings</Text>

      <Text style={styles.section}>Profile</Text>
      <GlassCard style={styles.card}>
        <Row title="Guest preview" detail="No account is connected in Phase 1." status={isAuthConfigured ? 'Prepared for Phase 2' : 'Requires backend configuration'} />
        <GradientButton label="Leave guest preview" variant="ghost" onPress={leave} />
      </GlassCard>

      <Text style={styles.section}>Appearance</Text>
      <GlassCard style={styles.card}>
        <Row title="Dark theme" detail="Virizz uses its dark purple theme." status="Implemented" />
        <Row title="Light theme" detail="Not available yet." status="Prepared for Phase 2" />
      </GlassCard>

      <Text style={styles.section}>Notifications</Text>
      <GlassCard style={styles.card}>
        <Row title="Push notifications" detail="No notifications are sent in Phase 1." status="Prepared for Phase 2" />
      </GlassCard>

      <Text style={styles.section}>Privacy</Text>
      <GlassCard style={styles.card}>
        <Row title="Your text" detail="In Phase 1 nothing you type leaves your device. No AI request is made." status="Implemented" />
        <Row title="AI backend" detail={isBackendConfigured ? 'A backend URL is set, but the client is not implemented yet.' : 'Not configured.'} status="Requires backend configuration" />
      </GlassCard>

      <Text style={styles.section}>About Virizz</Text>
      <GlassCard style={styles.card}>
        <Row title="Virizz Phase 1" detail={`Version ${version}. A stable app foundation. AI, accounts and sync come later.`} />
      </GlassCard>
    </Screen>
  );
}

const styles = StyleSheet.create({
  title: { color: colors.text, fontSize: 30, fontWeight: '800', marginTop: 8 },
  section: { color: colors.pink, fontSize: 13, fontWeight: '800', letterSpacing: 1, textTransform: 'uppercase', marginTop: 8 },
  card: { gap: 14 },
  row: { gap: 4 },
  rowTitle: { color: colors.text, fontSize: 16, fontWeight: '700' },
  rowDetail: { color: colors.textDim, fontSize: 13, lineHeight: 19, marginBottom: 4 },
});

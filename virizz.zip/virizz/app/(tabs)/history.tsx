import { StyleSheet, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { EmptyState } from '@/components/EmptyState';
import { GlassCard } from '@/components/GlassCard';
import { Notice } from '@/components/Notice';
import { Screen } from '@/components/Screen';
import { colors } from '@/constants/theme';
import { useLibrary } from '@/hooks/useLibrary';
import { formatDate, preview } from '@/lib/format';
import { safePush } from '@/lib/navigation';

export default function History() {
  const router = useRouter();
  const { history } = useLibrary();
  return (
    <Screen>
      <Text style={styles.title}>History</Text>
      <Notice status="Prepared for Phase 2" message="These are sample development items held in memory. Real history will be stored in a database later." />
      {history.length === 0 ? (
        <EmptyState emoji="🕒" title="No history yet" message="Generated messages will appear here." />
      ) : (
        history.map((item) => (
          <GlassCard key={item.id} onPress={() => safePush(router, `/item/${item.id}`)}>
            <View style={styles.row}>
              <Text style={styles.kind}>{item.kind}</Text>
              <Text style={styles.date}>{formatDate(item.createdAt)}</Text>
            </View>
            <Text style={styles.preview}>{preview(item.output)}</Text>
          </GlassCard>
        ))
      )}
    </Screen>
  );
}

const styles = StyleSheet.create({
  title: { color: colors.text, fontSize: 30, fontWeight: '800', marginTop: 8 },
  row: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6 },
  kind: { color: colors.pink, fontWeight: '700', fontSize: 12 },
  date: { color: colors.textFaint, fontSize: 12 },
  preview: { color: colors.textDim, fontSize: 14, lineHeight: 20 },
});

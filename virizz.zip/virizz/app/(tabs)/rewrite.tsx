import { AssistantForm } from '@/components/AssistantForm';
import { REWRITE_STYLES } from '@/constants/theme';
import { aiService } from '@/services/ai';

export default function RewriteScreen() {
  return (
    <AssistantForm
      title="Rewrite"
      subtitle="Improve the wording of your own message."
      inputLabel="Original message"
      placeholder="Type or paste your message…"
      optionLabel="Rewrite style"
      options={REWRITE_STYLES}
      initialOption="Clearer"
      actionLabel="Rewrite"
      action={(message, style) => aiService.rewriteMessage(message, style)}
    />
  );
}

import { useRef, useState } from 'react';
import { Animated, Image, Pressable, ScrollView, StyleSheet, Text, View, useWindowDimensions, type NativeScrollEvent, type NativeSyntheticEvent } from 'react-native';
import { useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeAreaView } from 'react-native-safe-area-context';
import { GradientButton } from '@/components/GradientButton';
import { colors, gradients, ONBOARDING_TONES, radius } from '@/constants/theme';
import { useSession } from '@/hooks/useSession';
import { safeReplace } from '@/lib/navigation';

interface Page {
  key: string;
  title: string;
  subtitle: string;
}

const PAGES: readonly Page[] = [
  { key: 'meet', title: 'Meet Virizz', subtitle: 'Virizz helps you write better messages: clearer replies, smoother wording, and the right words at the right time.' },
  { key: 'tone', title: 'Say it your way', subtitle: 'Pick the tone that fits the moment, whether it is playful or professional.' },
  { key: 'smart', title: 'Your words. Smarter.', subtitle: 'Reply, rewrite and start conversations with confidence. AI features arrive in a later phase.' },
];

export default function Onboarding() {
  const router = useRouter();
  const { completeOnboarding } = useSession();
  const { width } = useWindowDimensions();
  const scrollRef = useRef<ScrollView>(null);
  const scrollX = useRef(new Animated.Value(0)).current;
  const [index, setIndex] = useState(0);
  const last = index === PAGES.length - 1;

  const finish = () => {
    completeOnboarding();
    safeReplace(router, '/auth/sign-in');
  };

  const next = () => {
    if (last) return finish();
    scrollRef.current?.scrollTo({ x: width * (index + 1), animated: true });
  };

  const onEnd = (e: NativeSyntheticEvent<NativeScrollEvent>) => {
    if (width > 0) setIndex(Math.max(0, Math.min(PAGES.length - 1, Math.round(e.nativeEvent.contentOffset.x / width))));
  };

  return (
    <LinearGradient colors={gradients.background} style={styles.fill}>
      <SafeAreaView style={styles.fill}>
        <View style={styles.top}>
          {!last ? (
            <Pressable accessibilityRole="button" onPress={finish} hitSlop={12}>
              <Text style={styles.skip}>Skip</Text>
            </Pressable>
          ) : null}
        </View>

        <Animated.ScrollView
          ref={scrollRef}
          horizontal
          pagingEnabled
          showsHorizontalScrollIndicator={false}
          scrollEventThrottle={16}
          onScroll={Animated.event([{ nativeEvent: { contentOffset: { x: scrollX } } }], { useNativeDriver: false })}
          onMomentumScrollEnd={onEnd}
        >
          {PAGES.map((page, i) => {
            const range = [(i - 1) * width, i * width, (i + 1) * width];
            const opacity = scrollX.interpolate({ inputRange: range, outputRange: [0, 1, 0], extrapolate: 'clamp' });
            const translateY = scrollX.interpolate({ inputRange: range, outputRange: [30, 0, 30], extrapolate: 'clamp' });
            return (
              <Animated.View key={page.key} style={[styles.page, { width, opacity, transform: [{ translateY }] }]}>
                {page.key === 'tone' ? (
                  <View style={styles.tones}>
                    {ONBOARDING_TONES.map((tone) => (
                      <View key={tone} style={styles.tone}>
                        <Text style={styles.toneText}>{tone}</Text>
                      </View>
                    ))}
                  </View>
                ) : (
                  <Image source={require('../assets/images/icon.png')} style={styles.logo} accessibilityIgnoresInvertColors />
                )}
                <Text style={styles.title}>{page.title}</Text>
                <Text style={styles.subtitle}>{page.subtitle}</Text>
              </Animated.View>
            );
          })}
        </Animated.ScrollView>

        <View style={styles.dots}>
          {PAGES.map((page, i) => {
            const range = [(i - 1) * width, i * width, (i + 1) * width];
            const dotWidth = scrollX.interpolate({ inputRange: range, outputRange: [8, 26, 8], extrapolate: 'clamp' });
            const dotOpacity = scrollX.interpolate({ inputRange: range, outputRange: [0.35, 1, 0.35], extrapolate: 'clamp' });
            return <Animated.View key={page.key} style={[styles.dot, { width: dotWidth, opacity: dotOpacity }]} />;
          })}
        </View>

        <View style={styles.footer}>
          <GradientButton label={last ? 'Get Started' : 'Next'} onPress={next} />
        </View>
      </SafeAreaView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  fill: { flex: 1 },
  top: { height: 44, alignItems: 'flex-end', justifyContent: 'center', paddingHorizontal: 24 },
  skip: { color: colors.textDim, fontSize: 16, fontWeight: '600' },
  page: { alignItems: 'center', justifyContent: 'center', paddingHorizontal: 32, gap: 16 },
  logo: { width: 180, height: 180, borderRadius: 44, marginBottom: 16 },
  title: { color: colors.text, fontSize: 32, fontWeight: '800', textAlign: 'center' },
  subtitle: { color: colors.textDim, fontSize: 16, lineHeight: 24, textAlign: 'center' },
  tones: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center', gap: 10, marginBottom: 16 },
  tone: { paddingHorizontal: 18, paddingVertical: 10, borderRadius: radius.pill, backgroundColor: colors.glassStrong, borderWidth: 1, borderColor: colors.fuchsia },
  toneText: { color: colors.text, fontWeight: '700', fontSize: 15 },
  dots: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 6, height: 24 },
  dot: { height: 8, borderRadius: 4, backgroundColor: colors.pink },
  footer: { padding: 24 },
});

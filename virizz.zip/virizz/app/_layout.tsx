import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { colors } from '@/constants/theme';
import { LibraryProvider } from '@/hooks/useLibrary';
import { SessionProvider } from '@/hooks/useSession';

/** Expo Router renders this if any route throws, so the app never white-screens. */
export function ErrorBoundary({ error, retry }: { error: Error; retry: () => Promise<void> }) {
  return (
    <View style={styles.fallback}>
      <Text style={styles.title}>Something went wrong</Text>
      <Text style={styles.message}>{error.message || 'Unexpected error.'}</Text>
      <Pressable accessibilityRole="button" onPress={() => void retry()} style={styles.button}>
        <Text style={styles.buttonText}>Try again</Text>
      </Pressable>
    </View>
  );
}

export default function RootLayout() {
  return (
    <SafeAreaProvider>
      <SessionProvider>
        <LibraryProvider>
          <StatusBar style="light" />
          <Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: colors.bg }, animation: 'fade' }} />
        </LibraryProvider>
      </SessionProvider>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  fallback: { flex: 1, backgroundColor: colors.bg, alignItems: 'center', justifyContent: 'center', padding: 24, gap: 12 },
  title: { color: colors.text, fontSize: 22, fontWeight: '800' },
  message: { color: colors.textDim, fontSize: 14, textAlign: 'center' },
  button: { backgroundColor: colors.purple, paddingHorizontal: 24, paddingVertical: 12, borderRadius: 999 },
  buttonText: { color: colors.text, fontWeight: '700' },
});

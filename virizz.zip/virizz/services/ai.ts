import { config, isBackendConfigured } from '@/lib/config';
import { validateMessage } from '@/lib/validation';
import type { RewriteStyle, ServiceResult, Tone } from '@/types';

/**
 * AI SERVICE ABSTRACTION  (Phase 1: NOT CONNECTED)
 *
 * Every screen talks to AI only through this file. In Phase 2 the body of
 * `callBackend` will POST to a secure backend you own (EXPO_PUBLIC_API_URL),
 * and that backend holds the AI provider key. No AI key ever ships in the app.
 *
 * Phase 1 never fabricates AI output. It validates input and returns a
 * clearly-labelled "not connected" result.
 */

export interface AiTextResult {
  text: string;
}

export const AI_NOT_CONNECTED_MESSAGE =
  'AI service not connected yet. Virizz Phase 1 does not generate real AI text. A secure backend is planned for Phase 2.';

type AiRequest =
  | { task: 'reply'; message: string; tone: Tone }
  | { task: 'rewrite'; message: string; style: RewriteStyle }
  | { task: 'tone'; message: string; tone: Tone };

async function callBackend(_request: AiRequest): Promise<ServiceResult<AiTextResult>> {
  // PREPARED FOR PHASE 2: replace with fetch(`${config.apiUrl}/v1/generate`, ...)
  // plus timeout, auth token, and response validation.
  if (!isBackendConfigured) {
    return { ok: false, reason: 'not_configured', message: AI_NOT_CONNECTED_MESSAGE };
  }
  return {
    ok: false,
    reason: 'not_implemented',
    message: `A backend URL is set (${config.apiUrl}) but the request client is not implemented in Phase 1.`,
  };
}

async function run(request: AiRequest): Promise<ServiceResult<AiTextResult>> {
  const invalid = validateMessage(request.message);
  if (invalid) return { ok: false, reason: 'invalid_input', message: invalid };
  try {
    return await callBackend(request);
  } catch {
    return { ok: false, reason: 'unknown', message: 'Something went wrong. Please try again.' };
  }
}

export const aiService = {
  generateReply: (message: string, tone: Tone) => run({ task: 'reply', message, tone }),
  rewriteMessage: (message: string, style: RewriteStyle) => run({ task: 'rewrite', message, style }),
  changeTone: (message: string, tone: Tone) => run({ task: 'tone', message, tone }),
};

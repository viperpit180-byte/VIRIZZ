import type { LibraryItem } from '@/types';

/**
 * LIBRARY SERVICE — history + saved items.
 * Phase 1: SAMPLE data held in memory only (nothing is stored in a database).
 * Phase 2: replace with Supabase tables (history, saved) behind this interface.
 */
const day = 24 * 60 * 60 * 1000;
const ago = (days: number): string => new Date(Date.now() - days * day).toISOString();

export const SAMPLE_HISTORY: readonly LibraryItem[] = [
  { id: 'sample-1', kind: 'Reply', createdAt: ago(0), input: 'Hey, are we still on for Friday?', output: 'Sample reply (development data, not AI): Yes, still on! What time works for you?', sample: true },
  { id: 'sample-2', kind: 'Rewrite', createdAt: ago(1), input: 'i cant make it, sorry', output: 'Sample rewrite (development data, not AI): I am sorry, I will not be able to make it.', sample: true },
  { id: 'sample-3', kind: 'Starter', createdAt: ago(3), input: 'Topic: Friends', output: 'Sample starter (development data, not AI): What is the best thing you have watched lately?', sample: true },
  { id: 'sample-4', kind: 'Tone', createdAt: ago(6), input: 'Send me the file', output: 'Sample tone change (development data, not AI): Could you send me the file when you get a moment?', sample: true },
];

export const SAMPLE_SAVED: readonly LibraryItem[] = SAMPLE_HISTORY.slice(0, 1);

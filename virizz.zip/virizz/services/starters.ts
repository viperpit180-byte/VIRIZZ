import type { ServiceResult, StarterTopic } from '@/types';

/**
 * LOCAL DEVELOPMENT STARTERS — NOT AI.
 * A small hand-written list so the Conversation Starter screen can be tested
 * in Phase 1. Kept separate from services/ai.ts on purpose. In Phase 2 this
 * screen will call the AI service instead.
 */
const LOCAL_STARTERS: Record<StarterTopic, readonly string[]> = {
  Dating: [
    "What's something small that made you smile this week?",
    "If we could teleport anywhere for dinner tonight, where would you pick?",
    "What's a hobby you could talk about for an hour?",
  ],
  Friends: [
    "Random question: what's the best thing you've watched lately?",
    "We need to plan something soon. What have you been wanting to try?",
    "What's your current go-to comfort meal?",
  ],
  School: [
    "How are you finding the workload this term?",
    "Do you want to study together before the next test?",
    "Which class are you enjoying most right now?",
  ],
  Work: [
    "How's your week shaping up? Anything I can help with?",
    "What's the most interesting thing you're working on at the moment?",
    "Do you have a few minutes to chat about the project this week?",
  ],
  General: [
    "What's been the highlight of your week so far?",
    "Any recommendations — music, shows, or books?",
    "What's something you're looking forward to?",
  ],
};

let counter = 0;

export function createLocalStarter(topic: StarterTopic): ServiceResult<{ text: string; source: 'local-development' }> {
  const list = LOCAL_STARTERS[topic];
  if (!list || list.length === 0) {
    return { ok: false, reason: 'unknown', message: 'No starters available for that topic.' };
  }
  const text = list[counter % list.length] ?? list[0] ?? '';
  counter += 1;
  return { ok: true, data: { text, source: 'local-development' } };
}

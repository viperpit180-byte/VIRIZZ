import { isAuthConfigured } from '@/lib/config';
import { validateEmail, validatePassword } from '@/lib/validation';
import type { ServiceResult } from '@/types';

/**
 * AUTH SERVICE ABSTRACTION  (Phase 1: NOT CONNECTED)
 * Phase 2 will implement these with Supabase Auth using only the public anon
 * key. Until then every call returns an honest "not connected" result and the
 * app offers a clearly-labelled guest preview instead.
 */

export interface AuthUser {
  id: string;
  email: string;
}

export const AUTH_NOT_CONNECTED_MESSAGE =
  'Authentication is not connected yet (requires Supabase configuration in Phase 2). You can continue as a guest to preview the app.';

function notConnected<T>(): ServiceResult<T> {
  return {
    ok: false,
    reason: isAuthConfigured ? 'not_implemented' : 'not_configured',
    message: AUTH_NOT_CONNECTED_MESSAGE,
  };
}

export const authService = {
  isConfigured: isAuthConfigured,

  async signIn(email: string, password: string): Promise<ServiceResult<AuthUser>> {
    const invalid = validateEmail(email) ?? validatePassword(password);
    if (invalid) return { ok: false, reason: 'invalid_input', message: invalid };
    return notConnected();
  },

  async signUp(email: string, password: string): Promise<ServiceResult<AuthUser>> {
    const invalid = validateEmail(email) ?? validatePassword(password);
    if (invalid) return { ok: false, reason: 'invalid_input', message: invalid };
    return notConnected();
  },

  async sendPasswordReset(email: string): Promise<ServiceResult<null>> {
    const invalid = validateEmail(email);
    if (invalid) return { ok: false, reason: 'invalid_input', message: invalid };
    return notConnected();
  },
};
